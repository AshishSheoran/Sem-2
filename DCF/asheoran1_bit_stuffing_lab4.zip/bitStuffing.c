#include<stdio.h>
#define a_size 15
#define f_size 8
void main() {
	int a[a_size + 1] = { 0,1,1,1,1,1,1,0,1,1,1,1,1,1,0 };
	int b[30];
	int c[30];
	int flag[f_size + 1] = { 0,1,1,1,1,1,1,0 };

	int i = 0, j = 0, k = 0, cnt;

	while (i < a_size) {
		cnt = 1;
		if (a[i] == 1) {
			b[j] = a[i];

			for (k = i + 1; a[k] == 1 && k < a_size && cnt < 5; k++) {
				j++;
				b[j] = a[k];
				cnt++;

				if (cnt == 5) {
					j++;
					b[j] = 0;
				}
				i = k;
			}
		}
		else {
			b[j] = a[i];
		}
		i++;
		j++;
	}

	for (int n = 0; n < j + (2 * f_size); n++) {
		if (n < f_size) {
			c[n] = flag[n];
		}
		else if (n < j + f_size) {
			c[n] = b[n - f_size];
		}
		else {
			c[n] = flag[n - f_size - j];
		}
	}
	printf("Before stuffing: ");
	for (i = 0; i < a_size; i++) {
		printf("%d", a[i]);
	}
	printf("--%d characters\n", i);

	printf("After stuffing: ");
	for (i = 0; i < j; i++) {
		printf("%d", b[i]);
	}
	printf("--%d characters\n", j);

	printf("After framing: ");
	for (i = 0; i < j + (2 * f_size); i++) {
		printf("%d", c[i]);
	}
}